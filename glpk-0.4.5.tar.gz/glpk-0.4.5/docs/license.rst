=======
License
=======

PyGLPK is licensed under the GNU General Public License version 3. It is
copyright Thomas Finley at ``tfinley@gmail.com``. See the ``COPYING`` file in
the PyGLPK distribution for the GPL v3 license.

I am placing this documentation under the same license, that is, GPL.
