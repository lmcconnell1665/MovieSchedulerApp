========
Examples
========

.. include:: examples/ref.rst

.. include:: examples/maxflow.rst

.. include:: examples/sat.rst

.. include:: examples/ham.rst
