.. pyglpk documentation master file, created by
   sphinx-quickstart on Sat Jan  7 23:52:20 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyglpk's documentation!
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   discussion
   download
   building-installing
   examples
   brief-reference
   object-documentation
   glpk
   glpk-version-notes
   release-notes
   license



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
