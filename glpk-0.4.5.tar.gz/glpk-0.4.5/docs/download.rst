========
Download
========

You may download the source package from here:

`pyglpk-0.3.tar.bz2 <http://tfinley.net/software/pyglpk/pyglpk-0.3.tar.bz2>`_

An earlier version compatible with GLPK 4.4 onwards is here. This version also
builds against GLPK as late as GLPK 4.31, but is missing much of the
functionality added since GLPK 4.18:

`pyglpk-0.2.tar.bz2 <http://tfinley.net/software/pyglpk/pyglpk-0.2.tar.bz2>`_
